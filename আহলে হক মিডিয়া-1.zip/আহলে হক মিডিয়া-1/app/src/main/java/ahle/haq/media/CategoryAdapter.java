package ahle.haq.media;

import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.View;
import java.util.List;
import android.content.Context;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {
	private Context context;
	private List<Category> categoryList;

	public CategoryAdapter(Context context, List<Category> categoryList) {
		this.context = context;
		this.categoryList = categoryList;
	}

	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(context).inflate(R.layout.category_item, parent, false);
		return new ViewHolder(view);
	}

	@Override
	public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
		Category category = categoryList.get(position);
		holder.categoryName.setText(category.getName());
		holder.categoryName.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(context, activity_post.class);
				intent.putExtra("id", category.getId());
				context.startActivity(intent);
			}
		});
		holder.categoryCount.setText("(" + category.getCount() + ")");
	}

	@Override
	public int getItemCount() {
		return categoryList.size();
	}

	public static class ViewHolder extends RecyclerView.ViewHolder {
		TextView categoryName, categoryCount;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			categoryName = itemView.findViewById(R.id.categoryName);
			categoryCount = itemView.findViewById(R.id.categoryCount);
		}
	}
}