package ahle.haq.media;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.View;
import java.util.List;
import android.content.Context;

public class downloadAdapter extends RecyclerView.Adapter<downloadAdapter.ViewHolder> {
	private Context context;
	private List<Posts> categoryList;
	private PostDatabaseHelper dbHelper;

	public downloadAdapter(Context context, List<Posts> categoryList) {
		this.context = context;
		this.categoryList = categoryList;
		dbHelper = new PostDatabaseHelper(context);
	}

	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(context).inflate(R.layout.category_item, parent, false);
		return new ViewHolder(view);
	}

	@Override
	public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
		Posts category = categoryList.get(position);
		holder.categoryName.setText(category.getTitle());
		holder.categoryName.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(context, activity_webview.class);
				intent.putExtra("html", category.getContent());
				context.startActivity(intent);
				//Toast.makeText(context,category.getContent(),1).show();
			}
		});

		Drawable icon = context.getResources().getDrawable(R.drawable.del);

		// Resize the icon
		BitmapDrawable bitmapDrawable = (BitmapDrawable) icon;
		Bitmap bitmap = bitmapDrawable.getBitmap();
		Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, 35, 35, false);

		// Set the resized icon to the TextView
		Drawable resizedDrawable = new BitmapDrawable(context.getResources(), resizedBitmap);
		holder.categoryCount.setCompoundDrawablesWithIntrinsicBounds(resizedDrawable, null, null, null);
		//setCompoundDrawablesWithIntrinsicBounds(R.drawable.dw, 0, 0, 0);
		holder.categoryCount.setText("");
		holder.categoryCount.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int pos = holder.getAdapterPosition();

				if (pos != RecyclerView.NO_POSITION) {
					// DB থেকে ডিলিট
					dbHelper.deletePostById(categoryList.get(pos).getId());

					// লিস্ট থেকে রিমুভ
					categoryList.remove(pos);

					// RecyclerView আপডেট
					notifyItemRemoved(pos);
					notifyItemRangeChanged(pos, categoryList.size());

					Toast.makeText(context, "পোস্ট ডিলিট হয়ে গেছে", Toast.LENGTH_SHORT).show();
				}
			}
		});

	}

	@Override
	public int getItemCount() {
		return categ