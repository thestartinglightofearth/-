package ahle.haq.media;

import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.io.IOException;
import java.util.ArrayList;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.Iterator;
import java.util.List;
import okhttp3.Response;
import okhttp3.Request;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.OkHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
	private RecyclerView recyclerView;
	private CategoryAdapter adapter;
	private List<Category> categoryList;
	private String BASE_URL = "https://ahlehaqmedia.com/wp-json/wp/v2/categories?per_page=100&page=";
	private OkHttpClient client;
	private PostDatabaseHelper dbHelper;
	private ProgressBar progressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		dbHelper = new PostDatabaseHelper(MainActivity.this);
		recyclerView = findViewById(R.id.recyclerView);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		categoryList = new ArrayList<>();
		client = new OkHttpClient();
		progressBar = findViewById(R.id.progressBar);
		// Start the async task to fetch categories  
		new FetchCategoriesTask().execute();
	}

	private class FetchCategoriesTask extends AsyncTask<Void, Void, List<Category>> {

		@Override
		protected List<Category> doInBackground(Void... voids) {
			int page = 1;
			boolean hasMoreCategories = true;
			List<Category> fetchedCategories = new ArrayList<>();

			while (hasMoreCategories) {
				String categoryUrl = BASE_URL + page;
				try {
					Request request = new Request.Builder().url(categoryUrl).build();
					Response response = client.newCall(request).execute();

					if (!response.isSuccessful()) {
						break; // Stop if there's an error  
					}

					// Parse JSON response  
					String responseBody = response.body().string();
					try {
						JSONArray categories = new JSONArray(responseBody);

						if (categories.length() == 0) {
							hasMoreCategories = false;
						} else {
							for (int i = 0; i < categories.length(); i++) {
								JSONObject category = categories.getJSONObject(i);
								String categoryName = category.getString("name");
								int categoryCount = category.getInt("count");
								String catID = String.valueOf(category.getInt("id"));
								fetchedCategories.add(new Category(categoryName, categoryCount, catID));
							}
							page++; // Move to the next page  
						}
					} catch (Exception e) {
						print(e.toString());
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			return fetchedCategories;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressBar.setVisibility(View.VISIBLE); // লোডিং শুরু
		}

		@Override
		protected void onPostExecute(List<Category> result) {
			super.onPostExecute(result);
			if (result != null && !result.isEmpty()) {
				categoryList.clear();
				categoryList.addAll(result);

				// Initialize the adapter here, only once after all data is fetched  
				if (adapter == null) {
					progressBar.setVisibility(View.GONE);
					adapter = new CategoryAdapter(Ma