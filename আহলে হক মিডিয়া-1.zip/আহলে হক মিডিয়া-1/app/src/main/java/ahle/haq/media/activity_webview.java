package ahle.haq.media;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class activity_webview extends AppCompatActivity {
	private WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_webview);

		webView = findViewById(R.id.webview);

		// Direct HTML content as a string
		String htmlContent = getIntent().getStringExtra("html");

		// Load the HTML content into the WebView
		webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null);
	}

	@Override
	public void onBackPressed() {
		if (webView.canGoBack()) {
			webView.goBack(); // Navigate back within WebView
		} else {
			super.onBackPressed(); // Default behavior (close activity)
		}
	}
}