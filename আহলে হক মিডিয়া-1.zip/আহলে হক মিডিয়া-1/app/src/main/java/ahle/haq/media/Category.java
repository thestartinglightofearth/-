package ahle.haq.media;

public class Category {
    private String name;
    private int count;
	private String id;

    public Category(String name, int count,String id) {
        this.name = name;
        this.count = count;
		this.id = id;
    }

    public String getName() {
        return name;
    }
	public String getId(){
		return id;
	}
    public int getCount() {
        return count;
    }
}