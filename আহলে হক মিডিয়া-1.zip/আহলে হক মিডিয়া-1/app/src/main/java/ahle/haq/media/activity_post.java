package ahle.haq.media;

package ahle.haq.media;

import ahle.haq.media.Posts;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.io.IOException;
import java.util.ArrayList;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.Iterator;
import java.util.List;
import okhttp3.Callback;
import okhttp3.Call;
import okhttp3.Response;
import okhttp3.Request;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.OkHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class activity_post extends AppCompatActivity {
	private RecyclerView recyclerView;
	private PostAdapter adapter;
	private List<Posts> categoryList;
	private String BASE_URL;
	private OkHttpClient client;
	private int PAGE_NUM = 0;
	private ProgressBar progressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_post);
		recyclerView = findViewById(R.id.recyclerView);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		categoryList = new ArrayList<>();
		client = new OkHttpClient();
		progressBar = findViewById(R.id.progressBar);
		BASE_URL = "https://ahlehaqmedia.com/wp-json/wp/v2/posts?categories=" + getIntent().getStringExtra("id")
				+ "&per_page=10&page=";
		new FetchCategoriesTask().execute();

	}
	public void Home(View view) {
    Intent intent = new Intent(this, MainActivity.class);
    intent.addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP |
            Intent.FLAG_ACTIVITY_CLEAR_TASK |
            Intent.FLAG_ACTIVITY_NEW_TASK
    );
    startActivity(intent);
    finish();
}

	public void Next(View v) {
		new FetchCategoriesTask().execute();
	}

	public void Prev(View v) {
		PAGE_NUM = PAGE_NUM - 2;
		new FetchCategoriesTask().execute();
	}

	private class FetchCategoriesTask extends AsyncTask<Void, Void, List<Posts>> {

		@Override
		protected List<Posts> doInBackground(Void... voids) {
			PAGE_NUM += 1;
			int page = PAGE_NUM;

			List<Posts> fetchedCategories = new ArrayList<>();

			String categoryUrl = BASE_URL + page;
			try {
				Request request = new Request.Builder().url(categoryUrl).build();
				Response response = client.newCall(request).execute();

				if (!response.isSuccessful()) {
					;
					;// Stop if there's an error
				} else {

					// Parse JSON response
					String responseBody = response.body().string();
					try {
						JSONArray categories = new JSONArray(responseBody);

						if (categories.length() == 0) {
							;
							;
						} else {
							for (int i = 0; i < categories.length(); i++) {
								JSONObject category = categories.getJSONObject(i);
								String categoryName = category.getJSONObject("title").getString("rendered");
								String categoryCount = category.getJSONObject("content").getString("rendered");
								String catID = String.valueOf(category.getInt("id"));
								fetchedCategories.add(new Posts(categoryName, categoryCount, catID));
							}
						}
					} catch (Exception e) {
						print(e.toString());
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			return fetchedCategories;
		}
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressBar.setVisibility(View.VIS