package ahle.haq.media;

import android.database.Cursor;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.os.Bundle;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import androidx.recyclerview.widget.RecyclerView;

public class activity_download extends AppCompatActivity {
	private RecyclerView recyclerView;
	private List<Category> categoryList;
	private PostDatabaseHelper dbHelper;
	public List<Posts> postList;
	public downloadAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_download);
		dbHelper = new PostDatabaseHelper(activity_download.this);
		recyclerView = findViewById(R.id.recyclerView);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		postList = new ArrayList<>();
		try {
			Cursor cursor = dbHelper.getAllPosts();
			while (cursor.moveToNext()) {
				String postId = cursor.getString(cursor.getColumnIndex("post_id"));
				String title = cursor.getString(cursor.getColumnIndex("title"));
				String content = cursor.getString(cursor.getColumnIndex("content"));
				postList.add(new Posts(title, content, postId));
			}
			cursor.close();
			adapter = new downloadAdapter(activity_download.this, postList);
			recyclerView.setAdapter(adapter);
		} catch (Exception e) {
			;
			;
		}

	}
	public void Home(View v){
		finish();
	}
}