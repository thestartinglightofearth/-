package ahle.haq.media;

public class Posts {
    private String title;
    private String content;
	private String id;

    public Posts(String title, String content,String id) {
        this.title = title;
        this.content= content;
		this.id = id;
    }

    public String getTitle() {
        return title;
    }
	public String getId(){
		return id;
	}
    public String getContent() {
        return content;
    }
}